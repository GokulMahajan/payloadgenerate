package com.asb.example;

import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.apache.kafka.common.errors.SerializationException;
import org.apache.kafka.common.serialization.Deserializer;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;

import com.fasterxml.jackson.databind.ObjectMapper;

public class KafkaMessageDeserializer extends ErrorHandlingDeserializer<Result>
    implements Deserializer<Result> {
	
	@Override
	public void configure(Map<String, ?> map, boolean b) {
	}

	@Override
	public Result deserialize(String s, byte[] bytes) {
		if (bytes == null) {
			return null;
		}
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			return objectMapper.readValue(new String(bytes, StandardCharsets.UTF_8), Result.class);
		} catch (Exception e) {
			throw new SerializationException("Error when deserializing byte[] to messageDto");
		}
	}

	@Override
	public void close() {
	}
}
