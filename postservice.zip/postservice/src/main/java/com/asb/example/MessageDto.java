package com.asb.example;

public class MessageDto {
	private String name;
	private String percentage;
	private String result;
}
