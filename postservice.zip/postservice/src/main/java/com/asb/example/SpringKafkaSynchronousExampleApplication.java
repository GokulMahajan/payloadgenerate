package com.asb.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringKafkaSynchronousExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringKafkaSynchronousExampleApplication.class, args);
	}
}
