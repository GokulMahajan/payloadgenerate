package com.asb.example;

import java.time.Duration;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.requestreply.ReplyingKafkaTemplate;
import org.springframework.kafka.requestreply.RequestReplyFuture;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class KafkaController {

	@Value("${kafka.reuest.topic}")
	private String requestTopic;

	@Autowired
	private ReplyingKafkaTemplate<String, Student, Result> replyingKafkaTemplate;

	@PostMapping("/get-result")
	public ResponseEntity<Result> getObject(@RequestBody Student student)
			throws InterruptedException, ExecutionException {
		ProducerRecord<String, Student> record = new ProducerRecord<>(requestTopic, null, null, student);
		replyingKafkaTemplate.setDefaultReplyTimeout(Duration.ofMinutes(1));
		RequestReplyFuture<String, Student, Result> future = replyingKafkaTemplate.sendAndReceive(record);
		ConsumerRecord<String, Result> response = future.get();
		return new ResponseEntity<>(response.value(), HttpStatus.OK);
	}
	
	/*
	 * @PostMapping("/put-result") public ResponseEntity<Result>
	 * putObject(@RequestBody Student student) throws InterruptedException,
	 * ExecutionException { System.out.println("Calculating Result..."); double
	 * total = ThreadLocalRandom.current().nextDouble(2.5, 9.9); Result result = new
	 * Result(); result.setName(student.getName()); result.setResult((total > 3.5) ?
	 * "Pass" : "Fail"); result.setPercentage(String.valueOf(total *
	 * 10).substring(0, 4) + "%"); return new ResponseEntity<>(result,
	 * HttpStatus.OK); }
	 */
}