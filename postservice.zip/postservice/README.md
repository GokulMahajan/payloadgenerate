# Springboot Kafka Producer

This project explains now to implement Kafka in Springboot app

Kafka can be implemented using the auto configurations of springboot and manual configurations

This Project aims at using manual configurations as you would need to have much control on the stream in production.
